/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;


import javax.faces.FacesException;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.context.FacesContextFactory;
import javax.faces.lifecycle.Lifecycle;

import javax.portlet.PortletContext;
import javax.portlet.PortletRequest;
import javax.portlet.PortletResponse;
import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;


/**
 * <p>Custom implementation of <code>FacesContextFactory</code> that
 * provides the portlet-specific <code>FacesContext</code> by default.</p>
 */

public final class FacesContextFactoryImpl extends FacesContextFactory {
    
    // -------------------------------------------------------- Static Variables
    private static final String JSF_RI_FACES_CONTEXT = "com.sun.faces.context.FacesContextImpl";
    
    
    
    // --------------------------------------------- FacesContextFactory Methods
    
    
    public FacesContext getFacesContext(Object context,
            Object request,
            Object response,
            Lifecycle lifecycle)
            throws FacesException {
        if ((context == null) || (request == null) ||
                (response == null) || (lifecycle == null)) {
            throw new NullPointerException();
        }
        if (hasJSFRI() && context instanceof ServletContext) {
            ServletContextHandler servletWrapper = new ServletContextHandler();
            ExternalContext econtext =
                    servletWrapper.getExternalContextImpl((ServletContext) context,
                    (ServletRequest) request,
                    (ServletResponse) response);
            
            return servletWrapper.getFacesContextImpl(econtext, lifecycle);
            
        } else if(context instanceof PortletContext) {
            ExternalContext econtext =
                    new ExternalContextImpl((PortletContext) context,
                    (PortletRequest) request,
                    (PortletResponse) response);
            
            return (new FacesContextImpl(econtext, lifecycle));
        }
        return null;
    }
    
    // Check if the bridge is running with JSF RI
    private boolean hasJSFRI() {
        try {
            Class.forName(JSF_RI_FACES_CONTEXT);
        } catch (Throwable t) {
            return false;
        }
        return true;
    }
}
