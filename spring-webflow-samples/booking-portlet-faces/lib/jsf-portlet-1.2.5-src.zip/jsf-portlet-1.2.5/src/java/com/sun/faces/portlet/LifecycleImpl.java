/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;


import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;
import javax.el.ValueExpression;

import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.application.FacesMessage;
import javax.faces.application.ViewHandler;
import javax.faces.component.UIComponent;
import javax.faces.component.UIViewRoot;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.event.PhaseEvent;
import javax.faces.event.PhaseId;
import javax.faces.event.PhaseListener;
import javax.faces.lifecycle.Lifecycle;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;
import javax.faces.render.ResponseStateManager;

import javax.portlet.PortletConfig;
import javax.portlet.PortletSession;





// ------------------------------------------------------------- Private Classes


/**
 * <p>Custom implementation of <code>Lifecycle</code> that implements a
 * portlet-specific <code>Lifecycle</code>.</p>
 */

public final class LifecycleImpl extends Lifecycle {


    // -------------------------------------------------------- Static Variables


    // The Logger instance for this class
    private static Logger logger = Logger.getLogger(LifecycleImpl.class.getPackage().getName(), "JSFPLogMessages");

    /**
     * <p>Portlet session attribute (in portlet scope) under which we will
     * save the window state identifer. i.e one of the WINDOW_STATE_ATTR_* values.</p>
     */
    private static final String PREVIOUS_WINDOW_STATE =
            "com.sun.faces.portlet.PREVIOUS_WINDOW_STATE";

    /**
     * <p>Portlet session attribute (in portlet scope) under which we will
     * save state information for VIEW for the current window.</p>
     */
    private static final String WINDOW_STATE_ATTRIBUTE_VIEW =
            "com.sun.faces.portlet.WINDOW_STATE_VIEW";

    /**
     * <p>Portlet session attribute (in portlet scope) under which we will
     * save state information for EDIT for the current window.</p>
     */
    private static final String WINDOW_STATE_ATTRIBUTE_EDIT =
            "com.sun.faces.portlet.WINDOW_STATE_EDIT";

    /**
     * <p>Portlet session attribute (in portlet scope) under which we will
     * save state information for HELP for the current window.</p>
     */
    private static final String WINDOW_STATE_ATTRIBUTE_HELP =
            "com.sun.faces.portlet.WINDOW_STATE_HELP";


    /**
     * <p>A <code>request</code> scope attribute defining the
     * {@link RenderKit} being used for this request.
     */
    private static final String RENDER_KIT_IMPL_REQ =
          "com.sun.faces.portlet.renderKitImplForRequest";


    // ------------------------------------------------------ Instance Variables


    /**
     * <p>The set of <code>PhaseListener</code>s registered with this
     * <code>Lifecycle</code> instance, in order of registration.</p>
     */
    private CopyOnWriteArrayList<PhaseListener> listeners = new CopyOnWriteArrayList<PhaseListener>();


    /**
     * <p>The set of {@link Phase} instances that are to be
     * executed by the <code>execute()</code> method, in order by the
     * ordinal property of each phase.</p>
     */
    private Phase phases[] = {
        null, // ANY_PHASE holder
        new RestoreViewPhase(),
        new ApplyRequestValuesPhase(),
        new ProcessValidationsPhase(),
        new UpdateModelValuesPhase(),
        new InvokeApplicationPhase()
    };


    /**
     * <p>The {@link Phase} instance to process Render Response phase.</p>
     */
    private Phase response = new RenderResponsePhase();


    // ------------------------------------------------------------ Constructors


    /**
     * <p>Construct a new <code>LifecycleImpl</code> instance.</p>
     */
    public LifecycleImpl() {
        super();
        logger.log(Level.FINEST, "PS_CSFP0026", this);
    }


    // ------------------------------------------------------- Lifecycle Methods


    // Add a new PhaseListener to the set of registered listeners
    public void addPhaseListener(PhaseListener listener) {

        if (listener == null) {
            throw new NullPointerException();
        }
        if (logger.isLoggable(Level.FINER)) {
            logger.log(Level.FINER, "PS_CSFP0027", new Object[]{ listener.getPhaseId(), listener});
        }
        listeners.add(listener);
    }


    // Return the set of PhaseListeners that have been registered
    public PhaseListener[] getPhaseListeners() {

        PhaseListener results[] = new PhaseListener[listeners.size()];
        return ((PhaseListener[]) listeners.toArray(results));
    }


    // Remove a registered PhaseListener from the set of registered listeners
    public void removePhaseListener(PhaseListener listener) {

        if (listener == null) {
            throw new NullPointerException();
        }
        if (logger.isLoggable(Level.FINER)) {
            logger.log(Level.FINER, "PS_CSFP0030", new Object[] { listener.getPhaseId(),listener});
        }
        listeners.remove(listener);
    }

    // Execute the phases up to but not including Render Response
    public void execute(FacesContext context) throws FacesException {

        if (context == null) {
            throw new NullPointerException();
        }

        logger.log(Level.FINEST, "PS_CSFP0028", context);

        restore(context, true);

        setErrorFlag(context, Boolean.FALSE);

        for (int i = 1; i < phases.length; i++) {
            PhaseId phaseId = (PhaseId) PhaseId.VALUES.get(i);
            if (context.getRenderResponse() ||
                    context.getResponseComplete()) {
                /*
                    (a) If there are any validation/conversion errors, then its an error.
                    (b) If there are no validation/conversion errors, it means either
                    immediate=true is specified or FacesContext.renderResponse() has been
                    called.
                 */
                Iterator itr = context.getMessages();
                if(itr.hasNext()) {
                    setErrorFlag(context, Boolean.TRUE);
                }
                break;
            }
            phase(phaseId, phases[i], context);
        }

        save(context, true);

    }

    // Execute the Render Response phase
    public void render(FacesContext context) throws FacesException {
        if (context == null) {
            throw new NullPointerException();
        }

        logger.log(Level.FINEST, "PS_CSFP0029" , context);

        restore(context, false);

        setErrorFlag(context, Boolean.FALSE);

        if (!context.getResponseComplete()) {
            phase(PhaseId.RENDER_RESPONSE, response, context);
        }

        save(context, false);
    }

    // --------------------------------------------------------- Private Methods


    /**
     * <p>Execute the specified phase instance for the current request.</p>
     *
     * @param phaseId Phase identifier of the current phase
     * @param phase {@link Phase} instance to execute
     * @param context <code>FacesContext</code> for the current request
     *
     * @exception FacesException if thrown by the phase execution
     */
    private void phase(PhaseId phaseId, Phase phase, FacesContext context)
    throws FacesException {

        boolean exceptionThrownInRender = false;
        Exception tempException = null;

        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "PS_CSFP0031", new Object[] {phaseId, context});
        }

        // Acquire (once) the list of interested phase listeners
        // Clone it so that we are independent of changes during the
        // execution of this phase
        PhaseListener currentListeners[] = getPhaseListeners();

        try {

            // Notify the "beforePhase" method of interested listeners
            if (currentListeners.length > 0) {
                PhaseEvent event = new PhaseEvent(context, phaseId, this);
                for (int i = 0; i < currentListeners.length; i++) {
                    if (phaseId.equals(currentListeners[i].getPhaseId()) ||
                            PhaseId.ANY_PHASE.equals(currentListeners[i].getPhaseId())) {
                        currentListeners[i].beforePhase(event);
                    }
                }
            }

        } catch (Exception e) {

            // Log the problem, but continue
            if (logger.isLoggable(Level.INFO)) {
                LogRecord logRecord = new LogRecord(Level.INFO, "PS_CSFP0032");
                logRecord.setParameters(new Object[] { phaseId, context});
                logRecord.setThrown(e);
                logger.log(logRecord);
            }

        }

        try {

            try {

                // Execute this phase itself
                phase.execute(context);

            } catch (Exception e) {

                // Log the problem, but continue
                if (logger.isLoggable(Level.INFO)) {
                    LogRecord logRecord = new LogRecord(Level.INFO, "PS_CSFP0033");
                    logRecord.setParameters(new Object[] { phaseId, context});
                    logRecord.setThrown(e);
                    logger.log(logRecord);
                }

                // Don't rethrow as it will break the jsf lifecycle execution
                // If exception is thrown in the render phase, hold a reference to the exception
                if(phaseId.compareTo(PhaseId.RENDER_RESPONSE) == 0) {
                    exceptionThrownInRender = true;
                    tempException = e;
                }
            }

            // Notify the "afterPhase" method of interested listeners
            if (currentListeners.length > 0) {
                PhaseEvent event = new PhaseEvent(context, phaseId, this);
                for (int i = currentListeners.length - 1; i >= 0; i--) {
                    if (phaseId.equals(currentListeners[i].getPhaseId()) ||
                            PhaseId.ANY_PHASE.equals(currentListeners[i].getPhaseId())) {
                        currentListeners[i].afterPhase(event);
                    }
                }
            }

        } catch (Exception e) {

            // Log the problem, but continue
            if (logger.isLoggable(Level.INFO)) {
                LogRecord logRecord = new LogRecord(Level.INFO, "PS_CSFP0034");
                logRecord.setParameters(new Object[] { phaseId, context});
                logRecord.setThrown(e);
                logger.log(logRecord);
            }
        }

        if(exceptionThrownInRender)
            throw new FacesException(tempException);
    }


    /*
     * Check if CLEARING_STATE_ENABLED parameter is present in the portlet config and has the
     * value true. if yes, check if the clear state flag has been set as a request parameter or as request attribute.
     * If yes return true.
     */
    private boolean clearState(FacesContext context, PortletConfig portletConfig) {
        boolean clearStateValue = false;
        if("true".equals(portletConfig.getInitParameter(BridgeConstants.CLEARING_STATE_ENABLED)) ) {
            ExternalContext econtext = context.getExternalContext();
                if("true".equals((String)econtext.getRequestParameterMap().get(BridgeConstants.CLEAR_STATE))
                        || "true".equals((String)econtext.getRequestMap().get(BridgeConstants.CLEAR_STATE))) {
                    clearStateValue = true;
                }
        }
        return clearStateValue;
    }

    /**
     * <p>Restore state information for the current window into the
     * specified <code>FacesContext</code> instance.</p>
     *
     * @param context <code>FacesContext</code> for this request
     * @param action Flag indicating this is action mode (true)
     *  or render mode (false)
     */
    private void restore(FacesContext context, boolean action) {
        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "PS_CSFP0035", new Object[] { context,action});
        }

        PortletSession session = (PortletSession)context.getExternalContext().getSession(true);
        Map requestMap = context.getExternalContext().getRequestMap();
        PortletConfig portletConfig = (PortletConfig)requestMap.get("javax.portlet.PortletConfig");

        if(clearState(context, portletConfig)) {
            logger.log(Level.INFO, "PS_CSFP0080");
            session.removeAttribute(PREVIOUS_WINDOW_STATE);
        }

        // Retrieve the cached state information (if any)
        String windowStateIdentifier = getWindowStateIdentifier((String)requestMap.get(BridgeConstants.INIT_PARAMETER));

        String previousWindowStateIndentifier = (String)session.getAttribute(PREVIOUS_WINDOW_STATE);

        FacesPortletState state = null;
        // This will ensure that the state information saved for INIT_VIEW will be restored
        // only for INIT_VIEW and so on..
        if(previousWindowStateIndentifier != null
                && previousWindowStateIndentifier.equals(windowStateIdentifier)) {
            state = (FacesPortletState)session.getAttribute(windowStateIdentifier);

        }

        if(state != null) {
            if(state.getViewId().equals(portletConfig.getInitParameter(BridgeConstants.ERROR_PAGE))) {
                state = null;
            }
        }

        if (state == null) {
            setViewId(context, null);
            if(clearState(context, portletConfig)) {
                // Clear session map that may contain the session managed beans
                // The JSF Implementation will re-create session managed bean
                // if there is none
                Map sessionMap = context.getExternalContext().getSessionMap();
                if(sessionMap != null) {
                    sessionMap.clear();
                }
                // Trigger a switch to Render Response
                context.renderResponse();
            }
            return;
        }

        if (state.getViewRoot() == null){
            setViewId(context, state.getViewId());
            return;
        }
        logger.log(Level.FINE, "PS_CSFP0074", windowStateIdentifier);

        // Restore the cached state information
        if (!action) {
            Iterator messages;
            Iterator clientIds = state.getClientIds();
            while (clientIds.hasNext()) {
                String clientId = (String) clientIds.next();
                messages = state.getMessages(clientId);
                while (messages.hasNext()) {
                    context.addMessage(clientId, (FacesMessage) messages.next());
                }
            }
        }
        context.setViewRoot(state.getViewRoot());
        logger.log(Level.FINE, "PS_CSFP0075");

        // Remove the cached state information
        session.removeAttribute(windowStateIdentifier);

        logger.finest("PS_CSFP0036");
    }


    /**
     * <p>Save state information for the current window from the
     * specified <code>FacesContext</code> instance.</p>
     *
     * @param context <code>FacesContext</code> for this request
     * @param action Flag indicating this is action mode (true)
     *  or render mode (false)
     */
    private void save(FacesContext context, boolean action) {
        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "PS_CSFP0037", new Object[] { context, action });
        }
        // Save state information from this FacesContext
        FacesPortletState state = new FacesPortletState();
        Iterator messages;
        Iterator clientIds = context.getClientIdsWithMessages();
        while (clientIds.hasNext()) {
            String clientId = (String) clientIds.next();
            messages = context.getMessages(clientId);
            while (messages.hasNext()) {
                state.addMessage(clientId, (FacesMessage) messages.next());
            }
            // Log the message
            if (logger.isLoggable(Level.FINE)) {
                logger.log(Level.FINE, "PS_CSFP0038", clientId + state.getMessagesBuffer(clientId));
            }
        }
        state.setViewRoot(context.getViewRoot());
        logger.log(Level.FINE, "PS_CSFP0076");

        // Cache the state information in a session in portlet scope
        String windowStateIdentifier = getWindowStateIdentifier((String) context.getExternalContext().
                getRequestMap().get(BridgeConstants.INIT_PARAMETER));

        PortletSession session = (PortletSession)context.getExternalContext().getSession(true);
        // Save the window state identifier in a session in portlet scope
        // This information is used during restore to restore the cached information for the
        // appropriate window state. This will ensure that the state information saved for
        // INIT_VIEW will be restored only for INIT_VIEW and so on..
        session.setAttribute(PREVIOUS_WINDOW_STATE, windowStateIdentifier);

        session.setAttribute(windowStateIdentifier, state);
        logger.log(Level.FINE, "PS_CSFP0077", windowStateIdentifier);
    }


    /**
     * <p>Get the view identifier to a default page specified in a
     * portlet init parameter.</p>
     *
     * @param context <code>FacesContext</code> for the current request
     */
    private String getInitViewId(FacesContext context) {
        Map requestMap = context.getExternalContext().getRequestMap();
        String initParameterIdentifier = (String) requestMap.get(BridgeConstants.INIT_PARAMETER);
        String viewId = (String) requestMap.get(initParameterIdentifier);
        return viewId;
    }

    /**
     * <p>Set the view identifier to a default page specified in a
     * portlet init parameter.</p>
     *
     * @param context <code>FacesContext</code> for the current request
     * @param viewId the view identifier of the desired view
     */
    private void setViewId(FacesContext context, String viewId) {
        String errorPage = null;
        if(viewId == null) {
            // Check if there is an error
            PortletSession session = (PortletSession)context.getExternalContext().getSession(true);
            errorPage = (String)session.getAttribute(BridgeConstants.ERROR_PAGE);
            if(errorPage != null) {
                viewId = errorPage;
            } else {
                viewId = getInitViewId(context);
            }
         }

        if (context.getViewRoot() == null || errorPage != null) {
            context.setViewRoot(context.getApplication().getViewHandler().createView(context, viewId));
            if (logger.isLoggable(Level.FINER)) {
                logger.log(Level.FINER, "PS_CSFP0039", context.getViewRoot().getViewId());
            }
        } else {
            context.getViewRoot().setViewId(viewId);
            if (logger.isLoggable(Level.FINER)) {
                logger.log(Level.FINER, "PS_CSFP0040", viewId);
            }
        }

        context.getViewRoot().setRenderKitId(RenderKitFactory.HTML_BASIC_RENDER_KIT);
    }

    /**
     * Returns the window state attribute identifier based on the
     * init parameter identifier.
     *
     * @param initParameterIdentifier the initialization parameter identifier
     * @return window state attribute identifier
     */
    private String getWindowStateIdentifier(String initParameterIdentifier) {
        if(initParameterIdentifier.equals(BridgeConstants.INIT_VIEW_PARAMETER))
            return WINDOW_STATE_ATTRIBUTE_VIEW;
        else if(initParameterIdentifier.equals(BridgeConstants.INIT_EDIT_PARAMETER))
            return WINDOW_STATE_ATTRIBUTE_EDIT;
        else if(initParameterIdentifier.equals(BridgeConstants.INIT_HELP_PARAMETER))
            return WINDOW_STATE_ATTRIBUTE_HELP;
        else
            return null;

    }

    private void setErrorFlag(FacesContext context, Boolean value) {
        PortletSession session = (PortletSession)context.getExternalContext().getSession(true);
        session.setAttribute(BridgeConstants.ERROR_FLAG, value);
    }

    /**
     * <p>Obtain and return the {@link ResponseStateManager} for
     * the specified #renderKitId.</p>
     *
     * @param context the {@link FacesContext} of the current request
     * @param renderKitId {@link RenderKit} ID
     * @return the {@link ResponseStateManager} for the specified
     *  #renderKitId
     * @throws FacesException if an exception occurs while trying
     *  to obtain the <code>ResponseStateManager</code>
     */
    public static ResponseStateManager getResponseStateManager(
          FacesContext context, String renderKitId)
          throws FacesException {

        assert (null != renderKitId);
        assert (null != context);

        RenderKit renderKit = context.getRenderKit();
        if (renderKit == null) {
            // check request scope for a RenderKitFactory implementation
            Map<String, Object> requestMap =
                  context.getExternalContext().getRequestMap();
            RenderKitFactory factory = (RenderKitFactory)
                  requestMap.get(RENDER_KIT_IMPL_REQ);
            if (factory != null) {
                renderKit = factory.getRenderKit(context, renderKitId);
            } else {
                factory = (RenderKitFactory)
                      FactoryFinder
                            .getFactory(FactoryFinder.RENDER_KIT_FACTORY);
                if (factory == null) {
                    throw new IllegalStateException();
                } else {
                    requestMap.put(RENDER_KIT_IMPL_REQ, factory);
                }
                renderKit = factory.getRenderKit(context, renderKitId);
            }
        }
        return renderKit.getResponseStateManager();

    }

// ------------------------------------------------------- Phase Implementations


    interface Phase {

        public void execute(FacesContext context)
        throws FacesException;

    }


    final class RestoreViewPhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0041");
            // get the viewId from the context
            String viewId = context.getViewRoot().getViewId();
            if (viewId == null) {
                logger.info("PS_CSFP0042");
                throw new FacesException // PENDING - i18n
                        ("No view identifier in this request");
            }
            // Try to restore the view
            ViewHandler vh = context.getApplication().getViewHandler();
            UIViewRoot viewRoot = null;
            String renderkitId = context.getApplication().getViewHandler().
                                       calculateRenderKitId(context);
            ResponseStateManager rsm = getResponseStateManager(context, renderkitId);
            if (rsm.isPostback(context)) {
                logger.log(Level.FINEST, "PS_CSFP0085", viewId);
                viewRoot = vh.restoreView(context, viewId);
                if (viewRoot == null) {
                    logger.log(Level.INFO, "PS_CSFP0043", viewId);
                    viewRoot = vh.createView(context, viewId);
                    context.renderResponse();
                } else {
                    logger.log(Level.FINEST, "PS_CSFP0044", viewId);
                }
            } else {
                logger.log(Level.FINEST, "PS_CSFP0086", viewId);
                viewRoot = vh.createView(context, viewId);
            }
            context.setViewRoot(viewRoot);
            doPerComponentActions(context, viewRoot);
            logger.finest("PS_CSFP0045");
        }


        /**
         * <p>Do any per-component actions necessary during reconstitute</p>
         *
         * @param context the <code>FacesContext</code> for the current request
         * @param uiComponent the <code>UIComponent</code> to process the
         *  <code>binding</code> attribute
         */
        protected void doPerComponentActions(FacesContext context,
                UIComponent uiComponent) {

            // if this component has a component value reference expression,
            // make sure to populate the ValueExpression for it.
            ValueExpression valueExpression;
            if (null != (valueExpression = uiComponent.getValueExpression("binding"))) {
                valueExpression.setValue(context.getELContext(), uiComponent);
            }

            for (Iterator<UIComponent> kids =  uiComponent.getFacetsAndChildren();
            kids.hasNext(); ) {
                doPerComponentActions(context, kids.next());
            }
        }
    }


    final class ApplyRequestValuesPhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0046");
            UIViewRoot viewRoot = context.getViewRoot();
            try {
                viewRoot.processDecodes(context);
            } catch (FacesException e) {
                throw e;
            } catch (RuntimeException e) {
                throw new FacesException(e);
            }
            logger.finest("PS_CSFP0047");
        }
    }


    final class ProcessValidationsPhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0048");
            UIViewRoot viewRoot = context.getViewRoot();
            try {
                viewRoot.processValidators(context);
            } catch (FacesException e) {
                throw e;
            } catch (RuntimeException e) {
                throw new FacesException(e);
            }
            logger.finest("PS_CSFP0049");
        }

    }


    final class UpdateModelValuesPhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0050");
            UIViewRoot viewRoot = context.getViewRoot();
            try {
                viewRoot.processUpdates(context);
            } catch (FacesException e) {
                throw e;
            } catch (RuntimeException e) {
                throw new FacesException(e);
            }
            logger.finest("PS_CSFP0051");
        }

    }


    final class InvokeApplicationPhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0052");
            UIViewRoot viewRoot = context.getViewRoot();
            try {
                viewRoot.processApplication(context);
            } catch (FacesException e) {
                throw e;
            } catch (RuntimeException e) {
                throw new FacesException(e);
            }
            logger.finest("PS_CSFP0053");
        }

    }


    final class RenderResponsePhase implements Phase {

        public void execute(FacesContext context) throws FacesException {
            logger.finest("PS_CSFP0054");
            String requestURI = context.getViewRoot().getViewId();
            logger.log(Level.FINE, "PS_CSFP0055", requestURI);
            try {
                context.getApplication().getViewHandler().
                        renderView(context, context.getViewRoot());
            } catch (FacesException e) {
                throw e;
            } catch (IOException e) {
                throw new FacesException(e);
            }
            logger.finest("PS_CSFP0056");
        }

    }


}
/**
 * <p>Private class to represent the JavaServer Faces specific information
 * that is saved and restored for a particular window.
 */

final class FacesPortletState implements Serializable {

    // Methods Saving and Restoring Messages
    private Map messages = new HashMap(); // key=clientId, value=List of FacesMessage
    public void addMessage(String clientId, FacesMessage message) {
        List list = (List) messages.get(clientId);
        if (list == null) {
            list = new ArrayList();
            messages.put(clientId, list);
        }
        list.add(message);
    }
    public Iterator getMessages(String clientId) {
        List list = (List) messages.get(clientId);
        if (list != null) {
            return (list.iterator());
        } else {
            return (Collections.EMPTY_LIST.iterator());
        }
    }

    public StringBuffer getMessagesBuffer(String clientId) {
        List list = (List) messages.get(clientId);
        StringBuffer buffer = new StringBuffer();
        if (list != null) {
            Iterator currentMessages = list.iterator();
            FacesMessage message;
            while (currentMessages.hasNext()) {
                message = (FacesMessage) currentMessages.next();
                buffer.append(" ");
                buffer.append(message.getDetail());
            }
        }
        return buffer;
    }

    // Iterate over the client ids in this view
    public Iterator getClientIds() {
        return (messages.keySet().iterator());
    }

    // The UIViewRoot that is the root of our component tree
    // Since UIViewRoot is non serializable declare it transient
    private transient UIViewRoot viewRoot;

    public UIViewRoot getViewRoot() {
        return this.viewRoot;
    }

    public void setViewRoot(UIViewRoot viewRoot) {
        this.viewRoot = viewRoot;
        this.viewId = viewRoot.getViewId();
    }

    // Save the viewId so that a new viewRoot can be built in case of
    // serialization when UIViewRoot is not saved
    private String viewId;

    public String getViewId() {
        return viewId;
    }

    public void setViewId(String viewId) {
        this.viewId = viewId;
    }
}
