/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2007 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;

/**
 * BridgeConstants contains the constants used in the JSF Portlet Bridge classes.
 * 
 */
public class BridgeConstants {

    /**
     * <p>Portlet initialization parameter which holds the value of one of
     * initial mode identifier. i.e either INIT_VIEW_PARAMETER or
     * INIT_EDIT_PARAMETER or INIT_HELP_PARAMETER</p>
     */
    public static final String INIT_PARAMETER =
            "com.sun.faces.portlet.INIT";
    
    /**
     * <p>Portlet initialization parameter under which the application
     * may specify an initial view mode identifier to be displayed.</p>
     */
    public static final String INIT_VIEW_PARAMETER =
            "com.sun.faces.portlet.INIT_VIEW";
    
    /**
     * <p>Portlet initialization parameter under which the application
     * may specify an initial edit mode identifier to be displayed.</p>
     */
    public static final String INIT_EDIT_PARAMETER =
            "com.sun.faces.portlet.INIT_EDIT";
    
    /**
     * <p>Portlet initialization parameter under which the application
     * may specify an initial help mode identifier to be displayed.</p>
     */
    public static final String INIT_HELP_PARAMETER =
            "com.sun.faces.portlet.INIT_HELP";
    
    /**
     * <p>Portlet session attribute (in portlet scope) under which we will
     * save a Boolean TRUE or FALSE for the current window.</p>
     */
    public static final String ERROR_FLAG =
            "com.sun.faces.portlet.ERROR_FLAG";
    
    /**
     * <p>Portlet parameter under which the application
     * may specify an error page to be displayed in case of error.</p>
     */
    public static final String ERROR_PAGE =
            "com.sun.faces.portlet.ERROR_PAGE";

    /**
     * <p>Parameter which will indicate whether the JSF state 
     * should be cleared or not.</p>
     */
    public static final String CLEAR_STATE =
            "com.sun.faces.portlet.CLEAR_STATE";
    
    /**
     * <p>Portlet Parameter which will indicate whether the portlet
     * enables the clearing of the JSF state based on the 
     * com.sun.faces.portlet.CLEAR_STATE parameter.</p>
     */
    public static final String CLEARING_STATE_ENABLED =
            "com.sun.faces.portlet.CLEARING_STATE_ENABLED";

    /**
     * <p>Portlet Parameter which will indicate whether the portlet
     * should save the request scope till new action occurs.</p>
     */
    public static final String SAVE_REQUEST_SCOPE =
            "com.sun.faces.portlet.SAVE_REQUEST_SCOPE";

}
