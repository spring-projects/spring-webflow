/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;


import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.application.ViewHandler;
import javax.faces.component.UIViewRoot;
import javax.faces.context.FacesContext;
import javax.faces.context.ResponseWriter;
import javax.faces.FacesException;
import javax.faces.FactoryFinder;
import javax.faces.application.StateManager;
import javax.faces.context.ExternalContext;
import javax.faces.render.RenderKit;
import javax.faces.render.RenderKitFactory;

import javax.portlet.PortletURL;
import javax.portlet.RenderRequest;
import javax.portlet.RenderResponse;


/**
 * <p>Concrete implementation of <code>ViewHandler</code> for use in
 * a portlet environment.  This implementation delegates to the
 * standard <codeViewHandler</code> instance provided to our constructor,
 * and only implements portlet-specific behavior where necessary.</p>
 */

public final class ViewHandlerImpl extends ViewHandler {
    
    // -------------------------------------------------------- Static Variables
    
    
    /**
     * <p>The URL parameter we use to pass the view identifier of the
     * requested view.</p>
     */
    public static final String VIEW_ID_PARAMETER =
            "com.sun.faces.portlet.VIEW_ID";
    
    /**
     * <p>The URL parameter we use to pass the namespace of the portlet.</p>
     */
    public static final String NAME_SPACE_PARAMETER =
            "com.sun.faces.portlet.NAME_SPACE";
    
    private final static String FACES_PREFIX = "com.sun.faces.portlet.";
    
    private static final String SAVESTATE_FIELD_DELIMITER = "~";
    private static final String SAVESTATE_FIELD_MARKER =
            SAVESTATE_FIELD_DELIMITER
            + FACES_PREFIX
            + "saveStateFieldMarker"
            + SAVESTATE_FIELD_DELIMITER;
    
    private static final String AFTER_VIEW_CONTENT = FACES_PREFIX + "AFTER_VIEW_CONTENT";
    
    private static int RESPONSE_BUFFER_SIZE = 1024;
    
    private static final String INTERWEAVING_RESPONSE_INTERFACE = "com.sun.faces.application.InterweavingResponse";
    
    // The Logger instance for this class
    private static Logger logger = Logger.getLogger(ViewHandlerImpl.class.getPackage().getName(), "JSFPLogMessages");
    
    
    // ------------------------------------------------------ Instance Variables
    
    
    // The ViewHandler we delegate to
    private ViewHandler handler;
    
    
    // ------------------------------------------------------------- Constructor
    
    
    /**
     * <p>Construct a new <code>ViewHandler</code> instance that delegates
     * all non-portlet-specific behavior to the specified implementation.
     *
     * @param handler The <code>ViewHandler</code> instance to whom
     *  we can delegate
     *
     * @exception NullPointerException if <code>handler</code>
     *  is <code>null</code>
     */
    public ViewHandlerImpl(ViewHandler handler) {
        
        if (handler == null) {
            throw new NullPointerException();
        }
        logger.log(Level.FINE, "PS_CSFP0058", handler);
        this.handler = handler;
        
    }
    
    
    // ----------------------------------------------------- ViewHandler Methods
    
    
    public Locale calculateLocale(FacesContext context) {
        return (handler.calculateLocale(context));
    }
    
    
    public String calculateRenderKitId(FacesContext context) {
        return (handler.calculateRenderKitId(context));
    }
    
    
    public UIViewRoot createView(FacesContext context, String viewId) {
        if (null == context) {
            logger.severe("PS_CSFP0072");
        }
        UIViewRoot result = (UIViewRoot)context.getApplication().createComponent(UIViewRoot.COMPONENT_TYPE);
        
        if (viewId != null) {
            result.setViewId(viewId);
        }
        
        Locale locale = null;
        String renderKitId = null;
        
        // use the locale from the previous view if is was one which will be
        // the case if this is called from NavigationHandler. There wouldn't be
        // one for the initial case.
        if (context.getViewRoot() != null) {
            locale = context.getViewRoot().getLocale();
            renderKitId = context.getViewRoot().getRenderKitId();
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.log(Level.FINE, "PS_CSFP0059", viewId);
        }
        // PENDING(): not sure if we should set the RenderKitId here.
        // The UIViewRoot ctor sets the renderKitId to the default
        // one.
        // if there was no locale from the previous view, calculate the locale
        // for this view.
        if (locale == null) {
            locale = context.getApplication().getViewHandler().calculateLocale(context);
            if (logger.isLoggable(Level.FINE)) {
                logger.log(Level.FINE, "PS_CSFP0060", locale.toString());
            }
        } else {
            if (logger.isLoggable(Level.FINE)) {
                logger.log(Level.FINE, "PS_CSFP0061", locale.toString());
            }
        }
        
        if (renderKitId == null) {
            renderKitId =
                    context.getApplication().getViewHandler().calculateRenderKitId(
                    context);
            if (logger.isLoggable(Level.FINE)) {
                logger.log(Level.FINE, "PS_CSFP0062", renderKitId);
            }
        } else {
            if (logger.isLoggable(Level.FINE)) {
                logger.log(Level.FINE, "PS_CSFP0063", renderKitId);
            }
        }
        
        result.setLocale(locale);
        result.setRenderKitId(renderKitId);
        
        return result;
    }
    
    
    public String getActionURL(FacesContext context, String viewId) {
        Object r = context.getExternalContext().getResponse();
        if (!(r instanceof RenderResponse)) {
            logger.info("PS_CSFP0064");
            throw new IllegalStateException("Must be a RenderResponse");
        }
        RenderResponse response = (RenderResponse) r;
        PortletURL actionURL = response.createActionURL();
        actionURL.setParameter(VIEW_ID_PARAMETER, viewId);
        // A unique value is needed while saving values in the session.
        // As the render response namespace is unique, it is used.
        actionURL.setParameter(NAME_SPACE_PARAMETER, response.getNamespace());
        if(logger.isLoggable(Level.FINER)){
            logger.log(Level.FINER, "PS_CSFP0065", actionURL.toString());
        }
        return (actionURL.toString());
    }
    
    
    public String getResourceURL(FacesContext context, String path) {
        return (handler.getResourceURL(context, path));
    }
    
    
    public void renderView(FacesContext context, UIViewRoot viewToRender)
    throws IOException, FacesException {
        // suppress rendering if "rendered" property on the component is
        // false
        if (!viewToRender.isRendered()) {
            return;
        }
        
        ExternalContext extContext = context.getExternalContext();
        RenderRequest request =  (RenderRequest)extContext.getRequest();
        RenderResponse response = (RenderResponse)extContext.getResponse();
        
        try {
            if (executePageToBuildView(context, viewToRender)) {
                response.flushBuffer();
                return;
            }
        } catch (IOException e) {
            throw new FacesException(e);
        }
        if (logger.isLoggable(Level.FINE)) {
            logger.log(Level.FINE, "PS_CSFP0066", viewToRender.getViewId());
        }
        
        // set up the ResponseWriter
        RenderKitFactory renderFactory = (RenderKitFactory)
        FactoryFinder.getFactory(FactoryFinder.RENDER_KIT_FACTORY);
        RenderKit renderKit = renderFactory.getRenderKit(context, viewToRender.getRenderKitId());
        
        ResponseWriter oldWriter = context.getResponseWriter();
        
        WriteBehindStringWriter strWriter =
                new WriteBehindStringWriter(context, RESPONSE_BUFFER_SIZE);
        ResponseWriter newWriter;
        if (null != oldWriter) {
            newWriter = oldWriter.cloneWithWriter(strWriter);
        } else {
            newWriter = renderKit.createResponseWriter(strWriter, null, extContext.getRequestCharacterEncoding());
        }
        context.setResponseWriter(newWriter);
        
        newWriter.startDocument();
        
        doRenderView(context, viewToRender);
        
        newWriter.endDocument();
        
        // replace markers in the body content and write it to response.
        ResponseWriter responseWriter;
        if (null != oldWriter) {
            responseWriter = oldWriter.cloneWithWriter(response.getWriter());
        } else {
            responseWriter = newWriter.cloneWithWriter(response.getWriter());
        }
        context.setResponseWriter(responseWriter);
        if (logger.isLoggable(Level.FINE)) {
            logger.log(Level.FINE, "PS_CSFP0067", new Object[] { viewToRender, String.valueOf(strWriter.length())});
        }
        // flush directly to the response
        strWriter.flushToWriter(response.getWriter());
        
        if (null != oldWriter) {
            context.setResponseWriter(oldWriter);
        }
        
        // write any AFTER_VIEW_CONTENT to the response
        // side effect: AFTER_VIEW_CONTENT removed
        if(hasInterweavingResponse()) {
            ViewHandlerPortletRenderResponseWrapper wrapper = (ViewHandlerPortletRenderResponseWrapper)
            extContext.getRequestMap().remove(AFTER_VIEW_CONTENT);
            if (logger.isLoggable(Level.FINEST)) {
                logger.log(Level.FINEST, "PS_CSFP0079", wrapper.getResponse());
            }
            if (null != wrapper) {
                wrapper.flushToWriter(response.getWriter(),
                        response.getCharacterEncoding());
            }
        }
        response.flushBuffer();
    }
    
    
    public UIViewRoot restoreView(FacesContext context, String viewId) {
        if (null == context) {
            logger.severe("PS_CSFP0072");
        }
        
        ExternalContext extContext = context.getExternalContext();
        
        UIViewRoot viewRoot = null;
        
        // this is necessary to allow decorated impls.
        ViewHandler outerViewHandler =
                context.getApplication().getViewHandler();
        String renderKitId =
                outerViewHandler.calculateRenderKitId(context);
        viewRoot = context.getApplication().getStateManager().restoreView(context,
                viewId,
                renderKitId);
        if (logger.isLoggable(Level.FINEST)) {
            logger.log(Level.FINEST, "PS_CSFP0068", viewId);
        }
        
        return viewRoot;
    }
    
    public void writeState(FacesContext context) throws IOException {
        ResponseWriter writer = context.getResponseWriter();
        // Write the marker - used by WriteBehindStringWriter class
        writer.write(SAVESTATE_FIELD_MARKER);
    }
    
    /**
     * Execute the target view.  If the HTTP status code range is
     * not 2xx, then return true to indicate the response should be
     * immediately flushed by the caller so that conditions such as 404
     * are properly handled.
     * @param context the <code>FacesContext</code> for the current request
     * @param viewToExecute the view to build
     * @return <code>true</code> if the response should be immediately flushed
     *  to the client, otherwise <code>false</code>
     * @throws IOException if an error occurs executing the page
     */
    private boolean executePageToBuildView(FacesContext context,
            UIViewRoot viewToExecute)
            throws IOException {
        if (null == context) {
            logger.severe("PS_CSFP0072");
        }
        if (null == viewToExecute) {
            logger.severe("PS_CSFP0073");
        }
        String requestURI = viewToExecute.getViewId();
        logger.log(Level.FINE, "PS_CSFP0069", requestURI);
        
        ExternalContext extContext = context.getExternalContext();
        
        // replace the response with our wrapper
        if(hasInterweavingResponse()) {
            // save the original response
            Object originalResponse = extContext.getResponse();
            
            ViewHandlerPortletRenderResponseWrapper wrapper =
                    new ViewHandlerPortletRenderResponseWrapper((RenderResponse)extContext.getResponse());
            if (logger.isLoggable(Level.FINEST)) {
                logger.log(Level.FINEST, "PS_CSFP0079", wrapper.getResponse());
            }
            extContext.setResponse(wrapper);
            // build the view by executing the page
            extContext.dispatch(requestURI);
            
            logger.log(Level.FINE, "PS_CSFP0070", requestURI);
            
            // replace the original response
            extContext.setResponse(originalResponse);
            
            // Put the AFTER_VIEW_CONTENT into request scope
            // temporarily
            extContext.getRequestMap().put(AFTER_VIEW_CONTENT, wrapper);
        } else {
            // build the view by executing the page
            extContext.dispatch(requestURI);
            
            logger.log(Level.FINE, "PS_CSFP0070", requestURI);
        }
        
        return false;
    }
    
    /**
     * <p>This is a separate method to account for handling the content
     * after the view tag.</p>
     *
     * <p>Create a new ResponseWriter around this response's Writer.
     * Set it into the FacesContext, saving the old one aside.</p>
     *
     * <p>call encodeBegin(), encodeChildren(), encodeEnd() on the
     * argument <code>UIViewRoot</code>.</p>
     *
     * <p>Restore the old ResponseWriter into the FacesContext.</p>
     *
     * <p>Write out the after view content to the response's writer.</p>
     *
     * <p>Flush the response buffer, and remove the after view content
     * from the request scope.</p>
     *
     * @param context the <code>FacesContext</code> for the current request
     * @param viewToRender the view to render
     * @throws IOException if an error occurs rendering the view to the client
     */
    
    private void doRenderView(FacesContext context,
            UIViewRoot viewToRender)
            throws IOException, FacesException {
        if (logger.isLoggable(Level.FINE)) {
            logger.log(Level.FINE, "PS_CSFP0071", viewToRender.getViewId());
        }
        viewToRender.encodeAll(context);
    }
    
    // If the JSF RI does not contain InterweavingResponse interface skip
    // the content Interweaving logic
    private boolean hasInterweavingResponse() {
        try {
            Class.forName(INTERWEAVING_RESPONSE_INTERFACE);
        } catch (Throwable t) {
            return false;
        }
        return true;
    }
    
    // ----------------------------------------------------------- Inner Classes
    
    /**
     * <p>Handles writing the response from the dispatched request
     * and replaces any state markers with the actual
     * state supplied by the <code>StateManager</code>.
     */
    private static final class WriteBehindStringWriter extends Writer {
        
        // length of the state marker
        private static final int STATE_MARKER_LEN = SAVESTATE_FIELD_MARKER.length();
        
        // the context for the current request
        private final FacesContext context;
        
        // char buffer
        private final char[] buf;
        
        // buffer length
        private final int bufSize;
        
        protected StringBuilder builder;
        
        
        /**
         * <p>Create a new <code>WriteBehindStringWriter</code> for the current
         * request with an initial capacity.</p>
         * @param context the <code>FacesContext</code> for the current request
         * @param initialCapcity the StringBuilder's initial capacity
         */
        public WriteBehindStringWriter(FacesContext context, int initialCapacity) {
            builder = new StringBuilder(initialCapacity);
            this.context = context;
            bufSize = initialCapacity;
            buf = new char[bufSize];
        }
        
        /**
         * <p> Write directly from our FastStringWriter to the provided
         * writer.</p>
         * @param writer where to write
         * @throws IOException if an error occurs
         */
        public void flushToWriter(Writer writer) throws IOException {
            // Save the state to a new instance of StringWriter to
            // avoid multiple serialization steps if the view contains
            // multiple forms.
            StateManager stateManager =  context.getApplication().getStateManager();
            
            ResponseWriter origWriter = context.getResponseWriter();
            StringWriter state = new StringWriter((stateManager.isSavingStateInClient(
                    context)) ? bufSize : 128);
            context.setResponseWriter(origWriter.cloneWithWriter(state));
            stateManager.writeState(context, stateManager.saveView(context));
            context.setResponseWriter(origWriter);
            
            // begin writing...
            int totalLen = builder.length();
            StringBuffer stateBuffer = state.getBuffer();
            int stateLen = stateBuffer.length();
            int pos = 0;
            int tildeIdx = getNextDelimiterIndex(pos);
            while (pos < totalLen) {
                if (tildeIdx != -1) {
                    if (tildeIdx > pos && (tildeIdx - pos) > bufSize) {
                        // theres enough content before the first ~
                        // to fill the entire buffer
                        builder.getChars(pos, (pos + bufSize), buf, 0);
                        writer.write(buf);
                        pos += bufSize;
                    } else {
                        // write all content up to the first '~'
                        builder.getChars(pos, tildeIdx, buf, 0);
                        int len = (tildeIdx - pos);
                        writer.write(buf, 0, len);
                        // now check to see if the state saving string is
                        // at the begining of pos, if so, write our
                        // state out.
                        if (builder.indexOf(
                                SAVESTATE_FIELD_MARKER,
                                pos) == tildeIdx) {
                            // buf is effectively zero'd out at this point
                            int statePos = 0;
                            while (statePos < stateLen) {
                                if ((stateLen - statePos) > bufSize) {
                                    // enough state to fill the buffer
                                    stateBuffer.getChars(statePos,
                                            (statePos + bufSize),
                                            buf,
                                            0);
                                    writer.write(buf);
                                    statePos += bufSize;
                                } else {
                                    int slen = (stateLen - statePos);
                                    stateBuffer.getChars(statePos,
                                            stateLen,
                                            buf,
                                            0);
                                    writer.write(buf, 0, slen);
                                    statePos += slen;
                                }
                                
                            }
                        }
                        
                        // push us past the last '~' at the end of the marker
                        pos += (len + STATE_MARKER_LEN);
                        tildeIdx = getNextDelimiterIndex(pos);
                    }
                } else {
                    // we've written all of the state field markers.
                    // finish writing content
                    if (totalLen - pos > bufSize) {
                        // there's enough content to fill the buffer
                        builder.getChars(pos, (pos + bufSize), buf, 0);
                        writer.write(buf);
                        pos += bufSize;
                    } else {
                        // we're near the end of the response
                        builder.getChars(pos, totalLen, buf, 0);
                        int len = (totalLen - pos);
                        writer.write(buf, 0, len);
                        pos += (len + 1);
                    }
                }
            }
        }
        
        /**
         * @return return the length of the underlying
         * <code>StringBuilder</code>.
         */
        public int length() {
            return builder.length();
        }
        
        /**
         * <p>Get the next `~' from the StringBuilder.</p>
         * @param offset the offset from where to search from
         * @return the index of the first '~' from the specified
         *  offset
         */
        private int getNextDelimiterIndex(int offset) {
            return builder.indexOf(SAVESTATE_FIELD_DELIMITER,
                    offset);
        }
        
        // ----------------------------------------------------- Methods from Writer
        
        /**
         * <p>Write a portion of an array of characters.</p>
         *
         * @param cbuf Array of characters
         * @param off  Offset from which to start writing characters
         * @param len  Number of characters to write
         *
         * @throws IOException
         */
        public void write(char cbuf[], int off, int len) throws IOException {
            if ((off < 0) || (off > cbuf.length) || (len < 0) ||
                    ((off + len) > cbuf.length) || ((off + len) < 0)) {
                throw new IndexOutOfBoundsException();
            } else if (len == 0) {
                return;
            }
            builder.append(cbuf, off, len);
        }
        
        /**
         * <p>This is a no-op.</p>
         *
         * @throws IOException
         */
        public void flush() throws IOException {
        }
        
        /**
         * <p>This is a no-op.</p>
         *
         * @throws IOException
         */
        public void close() throws IOException {
        }
        
        /**
         * Write a string.
         *
         * @param str String to be written
         */
        public void write(String str) {
            builder.append(str);
        }
        
        /**
         * Write a portion of a string.
         *
         * @param str A String
         * @param off Offset from which to start writing characters
         * @param len Number of characters to write
         */
        public void write(String str, int off, int len) {
            builder.append(str.substring(off, off + len));
        }
        
        /**
         * Return the <code>StringBuilder</code> itself.
         *
         * @return StringBuilder holding the current buffer value.
         */
        public StringBuilder getBuffer() {
            return builder;
        }
        
        /** @return the buffer's current value as a string. */
        public String toString() {
            return builder.toString();
        }
        
        public void reset() {
            builder.setLength(0);
        }
    }
}
