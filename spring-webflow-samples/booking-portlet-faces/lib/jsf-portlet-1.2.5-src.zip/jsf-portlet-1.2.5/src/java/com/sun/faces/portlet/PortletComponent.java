/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;

import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.context.FacesContext;
import javax.faces.component.NamingContainer;
import javax.faces.component.UIComponentBase;
import javax.portlet.RenderResponse;


/**
 * <p><strong>PortletComponent</strong> is a {@link UIComponent} that
 * acts as a container for all JSF components in a portlet page. This component
 * works around the problem of "id" clashes in a portal environment where same
 * portlet can be deployed multiple times.This component overrides the
 * <code>getClientId()</code> method to prepend a unique <code>id</code>
 * everytime it is invoked, so that no two JSF components with in two
 * different portlets have the same <code>id</code>. If a <code>portletId</code>
 * is specified, it has to an EL expression and the application is responsible
 * for making sure that it is unique. If no <portletId> is specifed,
 * <code>PortletComponent</code> guarantees <code>id</code> uniqueness.
 */

public class PortletComponent extends UIComponentBase implements NamingContainer {
    
    
    // ------------------------------------------------------ Manifest Constants
    
    
    /**
     * <p>The standard component type for this component.</p>
     */
    public static final String COMPONENT_TYPE = "PortletComponent";
    
    
    /**
     * <p>The standard component family for this component.</p>
     */
    public static final String COMPONENT_FAMILY = "PortletComponent";
    
    // ------------------------------------------------------ Instance Variables
    
    // The Logger instance for this class
    private static Logger logger = Logger.getLogger(PortletComponent.class.getPackage().getName(), "JSFPLogMessages");
    
    
    // ------------------------------------------------------------ Constructors
    
    
    /**
     * <p>Create a new {@link PortletComponent} instance with default property
     * values.</p>
     */
    public PortletComponent() {
        
        super();
        
    }
    
    
    // -------------------------------------------------------------- Properties
    
    
    public String getFamily() {
        
        return (COMPONENT_FAMILY);
        
    }
    
    private String portletId = null;
    
    // ----------------------------------------------------- UIComponent Methods
    public String getClientId(FacesContext context) {
        if (portletId == null) {
            // generate a unique "id"
            portletId = createUniquePortletId(context);
            logger.log(Level.FINER, "PS_CSFP0057", portletId );
        }
        return portletId;
    }
    
    /**
     * Returns a unique PortletId for the portlet.
     * The namespace obtained from RenderResponse of the Portlet is used as its
     * unique.
     */
    private String createUniquePortletId(FacesContext context) {
        Object response = context.getExternalContext().getResponse();
        Class portletResponseClass = null;
        // Class.forName is used instead of instanceof to account for the case
        // where the porletPage tag is used in a webapp and portlet.jar is not
        // in classpath. In that scenario it will prevent ClassNotFoundException.
        try {
            portletResponseClass = Class.forName("javax.portlet.RenderResponse");
        } catch(ClassNotFoundException cnfe) {
            System.err.println(cnfe);
        }
        
        String portletId;
        if (portletResponseClass != null &&  portletResponseClass.isInstance(response)) {
            // Get the Namespace from Portlet RenderResponse as its
            //  unique in the context of the portal page.
            portletId = ((RenderResponse)response).getNamespace();
        } else {
            // If the response is not of that of Portlet, use any value.
            portletId = "dummy";
        }
        return portletId;
    }
}
