/*
 * CDDL HEADER START
 * The contents of this file are subject to the terms
 * of the Common Development and Distribution License
 * (the License). You may not use this file except in
 * compliance with the License.
 *
 * You can obtain a copy of the License at
 * http://www.sun.com/cddl/cddl.html and legal/CDDLv1.0.txt
 * See the License for the specific language governing
 * permission and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL
 * Header Notice in each file and include the License file
 * at legal/CDDLv1.0.txt.
 * If applicable, add the following below the CDDL Header,
 * with the fields enclosed by brackets [] replaced by
 * your own identifying information:
 * "Portions Copyrighted [year] [name of copyright owner]"
 *
 * Copyright 2006 Sun Microsystems Inc. All Rights Reserved
 * CDDL HEADER END
 */

package com.sun.faces.portlet;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.faces.lifecycle.Lifecycle;
import javax.faces.lifecycle.LifecycleFactory;


/**
 * <p>Custom implementation of <code>LifecycleFactory</code> that
 * provides the portlet-specific <code>Lifecycle</code> by default.</p>
 */

public final class LifecycleFactoryImpl extends LifecycleFactory {
    
    // The Logger instance for this class
    private static Logger logger = Logger.getLogger(LifecycleFactoryImpl.class.getPackage().getName(), "JSFPLogMessages");
    
    // ------------------------------------------------------------ Constructors
    
    private LifecycleFactory parent = null;
    
    public LifecycleFactoryImpl(LifecycleFactory parent) {
        this.parent = parent;
        logger.log(Level.FINE, "PS_CSFP0023", this);
        addLifecycle(LifecycleFactory.DEFAULT_LIFECYCLE, new LifecycleImpl());
    }
    
    // ------------------------------------------------------ Instance Variables
    
    
    // Registered Lifecycle instances, keyed by lifecycle identifier
    private Map<String,Lifecycle> lifecycles = new HashMap<String,Lifecycle>();
    
    
    // ---------------------------------------------------------- Public Methods
    
    
    public void addLifecycle(String lifecycleId, Lifecycle lifecycle) {
        
        if ((lifecycleId == null) || (lifecycle == null)) {
            throw new NullPointerException();
        }
        // For default lifecycle use portlet's lifecycle impl, for other
        // lifecycle delegate to the parent
        if(LifecycleFactory.DEFAULT_LIFECYCLE.equals(lifecycleId)) {
            synchronized (lifecycles) {
                if (lifecycles.containsKey(lifecycleId)) {
                    throw new IllegalArgumentException(lifecycleId);
                }
                lifecycles.put(lifecycleId, lifecycle);
            }
        } else {
            parent.addLifecycle(lifecycleId, lifecycle);
        }
        logger.log(Level.FINER, "PS_CSFP0024", lifecycleId);
    }
    
    
    public Lifecycle getLifecycle(String lifecycleId) {
        
        if (lifecycleId == null) {
            throw new NullPointerException();
        }
        // For default lifecycle use portlet's lifecycle impl, for other
        // lifecycle delegate to the parent
        if(LifecycleFactory.DEFAULT_LIFECYCLE.equals(lifecycleId)) {
            synchronized (lifecycles) {
                Lifecycle lifecycle = lifecycles.get(lifecycleId);
                if (lifecycle != null) {
                    if(logger.isLoggable(Level.FINER)){
                        logger.log(Level.FINER, "PS_CSFP0025", new Object[] { lifecycle, lifecycleId});
                    }
                    return (lifecycle);
                } else {
                    throw new IllegalArgumentException(lifecycleId);
                }
            }
        } else {
            return parent.getLifecycle(lifecycleId);
        }
    }
    
    
    public Iterator getLifecycleIds() {
        // Collect the lifecyle ids from the parent except the
        // default and also collect the lifecycle ids saved locally
        // and collate them.
        List<String> lifecycleIds = new ArrayList();
        for(Iterator<String> i = parent.getLifecycleIds(); i.hasNext(); ) {
            String lifecycleId = i.next();
            if(!LifecycleFactory.DEFAULT_LIFECYCLE.equals(lifecycleId)) {
                lifecycleIds.add(lifecycleId);
            }
        }
        for(Iterator<String> i = lifecycles.keySet().iterator(); i.hasNext(); ) {
            lifecycleIds.add(i.next());
        }
        return lifecycleIds.iterator();
    }
}
